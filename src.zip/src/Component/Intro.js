import React from "react";


class Intro extends React.Component{

render(){

  return(

    
    <section class="hero is-success is-fullheight">
    <div class="hero-body">
      <div class="container">
        <h1 class="title">
          Which is the best thriller of all  time !
        </h1>
        <h2 class="subtitle">
          Join the conversation
        </h2>
      </div>
    </div>
  </section>
 

  );


}
}

export default Intro ;

